﻿using Claims_WebAPI.Models;
using CsvHelper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Claims_WebAPI.Services
{
    public class CsvService:ICsvService
    {
        string csvFilepath;
        public CsvService(string csvFilepath)
        {
            this.csvFilepath = csvFilepath;
        }

        public IEnumerable<T> ReadCSV<T>(string csvFileName)
        {
            var streamReader = new StreamReader(csvFilepath + csvFileName);
            var csvReader = new CsvReader(streamReader, CultureInfo.InvariantCulture);
            return csvReader.GetRecords<T>();
        }
    }
}
