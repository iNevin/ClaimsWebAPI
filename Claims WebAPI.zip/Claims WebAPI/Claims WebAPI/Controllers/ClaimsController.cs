﻿using Claims_WebAPI.Models;
using Claims_WebAPI.Services;
using CsvHelper;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Claims_WebAPI.Controllers
{
    [Route("api")]
    [ApiController]
    public class ClaimsController : ControllerBase
    {
        private readonly ICsvService csvService;

        public ClaimsController(ICsvService csvService)
        {
            this.csvService = csvService;
        }

        // GET api/Claims?claimDate=10/6/2020
        [HttpGet]
        [Route("Claims")]
        public IEnumerable<MemberClaim> GetClaims(DateTime claimDate)
        {

            //var reader = new StreamReader(@"C:\Users\nevinPSI\OneDrive\Desktop\WebAPI-SampleProject\Claim.csv");
            //var csv = new CsvReader(reader, CultureInfo.InvariantCulture);
            //var claims = csv.GetRecords<Claim>();

            var memberClaims = new List<MemberClaim>();

            var claims = csvService.ReadCSV<Claim>("Claim.csv").Where(c=> c.ClaimDate <= claimDate);
            var members = csvService.ReadCSV<Member>("Member.csv");

            foreach (var claim in claims)
            {           
                var member = members.First(m => m.MemberID == claim.MemberID);
                if (member != null)
                {
                    var memberClaim = new MemberClaim();
                    memberClaim.MemberID = member.MemberID;
                    memberClaim.EnrollmentDate = member.EnrollmentDate;
                    memberClaim.FirstName = member.FirstName;
                    memberClaim.LastName = member.LastName;
                    memberClaim.ClaimDate = claim.ClaimDate;
                    memberClaim.ClaimAmount = claim.ClaimAmount;

                    memberClaims.Add(memberClaim);
                }               
            }
                              
            return memberClaims;
        }   
    }
}
